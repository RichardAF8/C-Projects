//Richard Forrester, CS210 (B) 
//11/21/2019
//This program is creates game where the user must guess the mystery word by choosing one letter at a time.

#include <cstdlib>
#include <time.h>  
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

class ListOfWords {
private:
	string wordList[100] = {}; //contains the word list
	int index = 0; //index position
	string word1 = ""; //contains the word that is being guessed

public:
	ListOfWords() { //Opens the word list and populates the the array with the strings
		ifstream input;
		input.open("wordlist.txt");

		while (getline(input, word1)) {
			wordList[index] = word1;
			index++;
		}
		input.close();

		index = rand() % 60; //chooses a random word from the list.
		word1 = wordList[index];
	}
	string getWord() {

		return word1;
	}
};

class LetterProccesor { //This is class is the blueprint for the setting up and executing the LetterProccesor game
    private:
		char letters[20] = {}; //contains the guessed letters
		int correct = 0; //keeps a count of correct letters guessed
		int temp = 0; 
		int fail = 0; //keeps count of failed guesses
		int characters;
		int index2 = 0;
		string word = ""; //contains the word that is being guessed
		string line = ""; //contains the concatenated string of guessed letters and empty dashes
		bool found = false; //false if

	public:
		LetterProccesor (string input){
			word = input;
		}

	void checkAnswer (char guess) { //checks to see if the guess matches any of the letters in the word
		line = "";
		
		letters[index2] = tolower(guess);
		index2++;

		characters = word.length();

		for (int x = 0; x < characters; x++) {
			found = false;

			for (int n : letters) { //checks for correct guess
				if (tolower(word[x]) == n) { 
					found = true; 
					line += word[x];
					line+= " ";  
					correct += 1; 
					break; 
				} 
			}
			if (found == false) { //prints a dash for letters that have yet to be guessed 
				line+= "_ ";
			}
		}
		if (correct == characters) {  //ends the game if you have guessed all the letters correctly
			fail = 6;  
		}
		else if (temp < correct || guess==' ') { //checks to see if you guessed a new letter correctly
			temp = correct; 
		} else { //lose a turn if no new letter was guessed correctly
			fail++; 
		}
		correct = 0; //re-sets correct guesses
	}

	int getFail() { //returns the value of how many incorrect guesses
		return this->fail;
	}

	string getWord() { //returns the word that is being guessed
		return word; 
	}

	string getLine() { //returns the line containing all the letters to be guessed as well as the correctly guessed letters
		return line; 
	}
	void showLetters() {
		
		for (char j : letters) {
			if (j != ' ') {
				cout << j << " ";
			}
		}
	}
};

class SnowManHat {
public:

	void show() { //snowman head
		cout << "          ___ \n";
		cout << "        _|___|_\n";
		cout << "       '=/* *\\='\n";
		cout << "         \\~_~/\n";
	}
};
class SnowManHead {
public:

	void show() { //head without the hat
		cout << "          ___\n";
		cout << "         /* *\\\n";
		cout << "         \\~_~/\n";
	}
};
class SnowManChest {
public:
	void show() {//snowman chest
		cout << "     \\__/ '-' \\__/_\n";
		cout << "     /  \\  o  /  \\\n";
	}
};
class SnowManWaist {
public:
	void show() {// snowman waist
		cout << "       / '---' \\\n";
		cout << "      |    o    |\n";
	}
};
class SnowManLeg{
public:
	void show (){//snowman leg
		cout << "---.---\\   o   /-----.---\n";
		cout << "        '-----'`\n";
	}
};


int main() {

	int round = 0;
	char choice = '1';

	srand(time(NULL)); 

	SnowManHat frosty;
	SnowManHead frosty2;
	SnowManChest frosty3;
	SnowManWaist frosty4;
	SnowManLeg frosty5;

	ListOfWords game1;
	LetterProccesor game(game1.getWord());

	//Game Explanation
	cout << "This is a HangMan Game (Climate Change Edition)\n";
	cout << "You have to guess the correct letters of the word before I, Frosty The Snowman, melt due to global warming.\n";
	cout << "For every incorrect guess Frosty will melt (5 Chances), but if you guess the correct letter then Tesla sells another car and frosty remains intact\n";
	cout << "Good Luck!\n\n\n";
	//FencePost Rule: Print out the SnowMan and line before the loop
	frosty.show();
	frosty3.show();	
	frosty4.show();
	frosty5.show();
	//allows the the object to print out the guessed lines without counting a guess
	game.checkAnswer(' ');

	cout << game.getLine();
	//while loop keeps the game going until round counter exceeds 5
	while ( round != 5) {
		cout << "\n\nTurns Left: " << 5 - round; //Keeps track of turns left
		cout << "\nLetters Choosen: ";
		game.showLetters();
		cout << "\nGuess: ";
		cin >> choice;
		cout << "\n\n\n";

		cin.clear(); //Stops from taking a bunch of bad input
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		game.checkAnswer(choice);

		round = game.getFail(); //makes the round counter equal to  the number of incorrect guesses.
		
		switch (round) { //switch statement to melt different parts of the snowman depending on the round(incorrect guesses)
			case 0:
				frosty.show();
				frosty3.show();
				frosty4.show();
				frosty5.show();
				break;
			case 1:
				frosty2.show();
				frosty3.show();
				frosty4.show();
				frosty5.show();
				break;
			case 2:
				frosty3.show();
				frosty4.show();
				frosty5.show();
				break;
			case 3:
				frosty4.show();
				frosty5.show();
				break;
			case 4:
				frosty5.show();
				break;
			case 5:
				cout << "\n\n\nYou Lose!!\nSHAME ON YOU!\n";
				cout << "\nAll letters choosen were: "; 
				game.showLetters();
				cout << "\n\nThe correct answer is in fact: " << game.getWord()<<"\n\n";
				return 7;
			case 6:
				cout << "\n\nYOU WIN!!\n";
				cout << "\nAll letters choosen were: ";
				game.showLetters();
				cout << "\n\nThe correct word is: " << game.getWord() << "\n\n";
				return 7;
		}
		cout << game.getLine();
	}
}


