#include <iostream>
#include <fstream>

using namespace std;

class Stack{

    private:
		string stackList[100] = {}; //stack for strings
		int index = -1;
		int  stackListInt[100] = {};//stack for ints
		int item = 0; //keeps track of number of items in stack
		int item2 = 0;
		int size = (sizeof(stackList) / sizeof(string))-1; 
		
	public:
		void push (string a) { //inputs variable to top of stack
			if (item == size+1) {  //checks if stack is full
				cout << "Full!" << endl;
				return; 
			}
			else if (stackList[0] == "") {
				stackList[0] = a;
				item++;
			} else {
				for (int h = size; h > 0;h--) {
					stackList[h] = stackList[h - 1];
				}
				stackList[0] = a;
				item++;
			}
		}

		void pushInt(int k) { //inuts to int stack
			if (item2 == size+1) { 
				cout << "Full!" << endl;
				return; 
			}
			else if (stackListInt[0] == NULL) {
				stackListInt[0] = k;
				item2++;
			}
			else {
				for (int h = size; h > 0;h--) {
					stackListInt[h] = stackListInt[h - 1];
				}
				stackListInt[0] = k;
				item2++;
			}
		}

		void popInt() {//removes variable from stack
			if (item2 == 0) {
				cout << "Empty!Stack";
				return;
			}
			else {
				for (int x = 0; x < size;x++) {
					stackListInt[x] = stackListInt[x + 1];
				}
				item2--;
			}
		}

	    void pop() {//removes variable from stack
			if (item == 0) {
				cout << "Empty!Stack";
				return;
			}
			else {
				for (int x = 0; x < size;x++) {
					stackList[x] = stackList[x + 1];
				}
				item--;
			}
		}

		string top() { //returns top of stack
			return stackList[0];
		}
		
		int topInt() { 
			return stackListInt[0];
		}

		bool empty() { //returns status of empty
			if (item == 0) {
				return true;
			}
			else { 
				return false; 
			}
		}	
};

class CircleQueue {

private:
	int front = -1;
	int rear = -1;
	char queue[20] = {};
	bool empty= true;

public:
	void enQueue(char a) { //inserts item into CircleQueue
		if ((front == 0 && rear == 19) || (rear == (front - 1))) {
			cout << "\nQueue is Full" << endl;
		}
		else if (front == -1) {///* Insert First Element */
			front = rear = 0;
			queue[rear] = a;
			empty = false;
		}
		else if (rear == 19) {
			rear = 0;
			queue[rear] = a;
		} else {
			rear++;
			queue[rear] = a;
		}
	}

	void deQueue() { //Removes item from CircleQueue
		if (front == -1) {
			cout << "\nQueue is Empty" << endl;
		}
		else if (front == rear) {
			queue[front] = NULL;
			front = rear = -1;
			empty = true;
		}
		else if (front == 19) {
			queue[front] = NULL;
			front = 0;
		} else {
			queue[front] = NULL;
			front++;
		}
	}

	char getFront() { //returns front value in stack
		return queue[front];
	}
	char getRear() { //returns the last item in the stack
		return queue[rear];
	}
	bool isEmpty() { //returns if stack is empty or not
		return empty;
	}
};

class PostfixToInfix{ //converts from postfix to infix

private:
	Stack myStack;
	Stack stackListInt;
	CircleQueue queue;
	string infix;
	ifstream input;
	int answer = 0;
	bool queueStatus;
	int num1 = 0;
	int num2 = 0;
	string variable1 = "";
	string variable2 = "";

public:
	void convert(){ //Uses circleQueue and stack to convert from postfix to infix
		queueStatus = false;

		while (queueStatus == false) {
			 string s(1, queue.getFront()); //converts char to string
			 
			 if (s == "+" || s == "-" || s == "*" || s == "/") { //if operand evaluates and creates a temp infix expression
				variable1 = myStack.top();
				num1 = myStack.topInt();

				myStack.pop();
				myStack.popInt();

				variable2 = myStack.top();
				num2 = myStack.topInt();

				myStack.pop();
				myStack.popInt();

				switch (queue.getFront()) { //evaluates the operand
					case '+':
						answer = num2 + num1;
						break;
					case '-':
						answer = num2 - num1;
						break;
					case '/':
						answer = num2 / num1;
						break;
					case '*':
						answer = num2 * num1;
						break;
					default:
						break;
				}
				s = "(" + variable2 + s + variable1 + ")"; //stores current infix expression
				infix = s + " = ";
				//pushes  the final string and int back into top of stack
				myStack.push(s);
				myStack.pushInt(answer);
				queue.deQueue();
			} else { //if number pushes to the stack
				answer = queue.getFront() - '0';
				myStack.pushInt(answer);
				myStack.push(s);
				queue.deQueue();
			}
			queueStatus = queue.isEmpty();
		}
		//empties stack for next expression
		myStack.pop();
		myStack.popInt();
		cout << infix<< answer <<"\n"; //prints out infix and answer
	}

	void fileToQueue() { //reads text file full of postfix expressions
	    char c;
		input.open("postfix.txt");
		//evaluate if the character is a newline character (\n) or a regular character.   
		while (input.get(c)) {
			if (c == '\n') { //Upon reaching the newline character, evaluate the postfix expression stored in the character queue 
				convert();
			}
			else {//If the character is a regular character, it must be stored in the circular queue
				queue.enQueue(c);
			}		
		}
		input.close();
	}
};

int main(){
	PostfixToInfix john;
	john.fileToQueue();
}